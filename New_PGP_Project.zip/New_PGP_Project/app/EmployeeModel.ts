
export class EmployeeModel { 
employee_Id: number;
emplyeeName: string;
gender: string;
dateOfBirth: string;
mobileNumber: number;
emailId: string;
designation: string;
joinDate: string;
address: string;
qualification: string;
experiance: number;
batchCount: number;
placementCount: number;
}